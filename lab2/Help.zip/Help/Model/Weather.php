<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Weather
 *
 * @author webre
 */
class Weather implements Weather_Interface {

    //put your code here
    private $url;

    public function __construct() {
       
    }

    public function get_cities() {
   
    }

    public function get_weather($cityid) {
      
    }

    public function get_current_time() {
        
    }

}
