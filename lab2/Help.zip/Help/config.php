<?php
define("__WEATHER_URL","http://api.openweathermap.org/data/2.5/weather?id={{cityid}}&lang=en&units=metric&APPID=b6de1af4989ae03601fbfd07e804f454");
define("__CITIES_FILE", "resources/city.list.json");
